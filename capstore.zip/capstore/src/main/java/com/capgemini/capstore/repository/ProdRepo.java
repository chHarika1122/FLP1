package com.capgemini.capstore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.capstore.bean.Product;

public interface ProdRepo  extends JpaRepository<Product,Integer>{

	/*
	 * @Query("from Product product where product.prod_Id = :prod_Id") Product
	 * findProduct(@Param("prod_Id") Long prod_Id);
	 */
}
