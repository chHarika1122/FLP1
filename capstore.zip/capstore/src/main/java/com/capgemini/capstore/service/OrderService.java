package com.capgemini.capstore.service;

import java.util.List;

import com.capgemini.capstore.bean.Carddetails;
import com.capgemini.capstore.bean.CartList;
import com.capgemini.capstore.bean.Customer_Orders;
import com.capgemini.capstore.bean.PriceDetails;
import com.capgemini.capstore.bean.Product;

public interface OrderService {
	public Carddetails insertCardDetails(Carddetails card);
	public List<Customer_Orders> showOrders();
	public List<Carddetails> showDetails();
	public Product addProducts(Product prod);
	public List<Product> showProductDetails();
	public PriceDetails addPriceDetails(PriceDetails pri);
	public List<PriceDetails> showPriceDetails();
	
	
	public CartList addToCart(Long prod_Id);
	public List<CartList> displayCartList(Long cust_Id);
	
}
