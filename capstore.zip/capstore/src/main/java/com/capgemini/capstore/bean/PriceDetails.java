package com.capgemini.capstore.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="pricedetails")
public class PriceDetails {
	
	@Id
	@Column(name="product_Id")
	private long productId;
	
	@Column(name="product_Name")
	private String productName;
	@Column(name="product_Price")
	private double productPrice;
	@Column(name="product_Quantity")
	private long productQuantity;
	@Column(name="Total")
	private long total;
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	public long getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(Long long1) {
		this.productQuantity = long1;
	}
	public long getTotal() {
		return total;
	}
	public void setTotal(long total) {
		this.total = total;
	}
	public long getProductId() {
		return productId;
	}
	public void setProductId(long productId) {
		this.productId = productId;
	}

}
