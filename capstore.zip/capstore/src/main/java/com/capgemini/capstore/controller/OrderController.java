package com.capgemini.capstore.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.bean.Carddetails;
import com.capgemini.capstore.bean.CartList;
import com.capgemini.capstore.bean.Customer_Orders;
import com.capgemini.capstore.bean.PriceDetails;
import com.capgemini.capstore.bean.Product;
import com.capgemini.capstore.service.IOrderService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class OrderController {

	@Autowired
	IOrderService service;
	@GetMapping("/total")
	public ResponseEntity<List<Customer_Orders>> getOrders() {
		List<Customer_Orders> list = new ArrayList<>();
		list = service.showOrders();
		return ResponseEntity.ok(list);
	}
	
	@GetMapping("/card")
	public ResponseEntity<List<Carddetails>> getDetails(){
		List<Carddetails> list = new ArrayList<>();
		list = service.showDetails();
		return ResponseEntity.ok(list);
		
	}
	
	@PostMapping("/total/card")
	public ResponseEntity<Carddetails> addCardDetails(@RequestBody Carddetails card){
		Carddetails result = service.insertCardDetails(card);
		return ResponseEntity.ok(result);
		
	}
	
	@GetMapping("/showprod")
	public ResponseEntity<List<Product>> getProductDetails(){
		List<Product> list2 = new ArrayList<>();
		list2 = service.showProductDetails();
		return ResponseEntity.ok(list2);
		
	}
	
	@PostMapping("/proddetail")
	public ResponseEntity<Product> addProductDetails(@RequestBody Product prod){
		Product res = service.addProducts(prod);
		return ResponseEntity.ok(res);
		
	}
	@PostMapping("/pricedetail")
	public ResponseEntity<PriceDetails> showprice(@RequestBody PriceDetails pri){
		PriceDetails res = service.addPriceDetails(pri);
		return ResponseEntity.ok(res);
		
	}

	@GetMapping("/showprice")
	public ResponseEntity<List<PriceDetails>> getPriceDetails(){
		List<PriceDetails> list2 = new ArrayList<>();
		list2 = service.showPriceDetails();
		return ResponseEntity.ok(list2);
		
	}
	
	//payment details
	@PostMapping(value = "/cartlist/paymentDetails")
	public ResponseEntity<CartList> addToCartList(@PathVariable("prod_Id") Long prod_Id) {
		System.out.println(prod_Id);
		CartList result = service.addToCart(prod_Id);
		return new ResponseEntity<CartList>(result, HttpStatus.OK);
	}
	/*@PostMapping(value = "/cartlist/{prod_Id}")
	public ResponseEntity<CartList> addToCartList(@PathVariable("prod_Id") Long prod_Id) {
		System.out.println(prod_Id);
		CartList result = service.addToCart(prod_Id);
		return new ResponseEntity<CartList>(result, HttpStatus.OK);
	}*/

//	@GetMapping(value = "/cartlist/price/{cust_Id}")
//	public ResponseEntity<List<PriceDetails>> displayCartList(@PathVariable("cust_Id") Long cust_Id) {
//		
//		List<PriceDetails> list=new ArrayList<>();
//		list = service.displayCartList(cust_Id);
//		return ResponseEntity.ok(list);
//
//	}
	
	
	
	
	@PostMapping(value = "/cartlist/price/{cust_Id}")
	public ResponseEntity<PriceDetails> calculateTotalPrice(@PathVariable("cust_Id") Long cust_Id) {
		System.out.println(cust_Id);
		PriceDetails result = service.calculateTotalAmount(cust_Id);
		return new ResponseEntity<PriceDetails>(result, HttpStatus.OK);
	}
	
	@GetMapping(value = "/cartlist/total")
	public ResponseEntity<List<PriceDetails>> showTotalList() {
		
		List<PriceDetails> list=new ArrayList<>();
		list = service.displayTotalList();
		return ResponseEntity.ok(list);

	}
	
}
