import { Component, OnInit } from '@angular/core';
import { CustService } from '../cust.service';
@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  // template: `
  //   <nav class="navbar">

  //     <!-- logo -->
  //     <div class="navbar-brand">
  //       <a class="navbar-item">
  //         <img src="assets/img/bcd.jpg">
  //       </a>
  //     </div>
  //   </nav>
  // `,
  
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
dataset: any;
result: any
  submitted = false;
  results: any;
  constructor(private service: CustService) { }

  ngOnInit() {
    this.SearchDetails()
  }
  
  SearchDetails(): void {
    this.service.getSearchDetails().subscribe(data => {
      this.result = data;
      this.submitted = true;
      console.log(this.result);
    });
  }
  searchByName(event) {
    this.result = this.result.filter(singleItem =>
      singleItem.productName.toLowerCase().includes(event.target.value.toLowerCase())
    )
  }
}
