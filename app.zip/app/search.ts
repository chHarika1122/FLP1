export class Search {
    productId:any;
    productName:string;
    productPrice:any;
    productImage:any;
    
}
