import { Pipe, PipeTransform } from '@angular/core';

import { Product } from './product';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

 transform(items: any[], searchByName: string): any[] {

    if (!items) {
       return [];
    }
    if (!searchByName) {
      return items;
    }
    searchByName = searchByName.toLocaleLowerCase();

   return items.filter(it => {
     return it.toLocaleLowerCase().includes(searchByName);
    });
   }

}
