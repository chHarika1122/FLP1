export class Card {
    card_holder_name:string;
    cardNo:any;
    expiry_year:any;
    expiryMonth:any;
    cvv:any;
}
