import { Component, OnInit } from '@angular/core';
import { CustService } from '../cust.service';
@Component({
  selector: 'app-displayproducts',
  templateUrl: './displayproducts.component.html',
  styleUrls: ['./displayproducts.component.css']
})
export class DisplayproductsComponent implements OnInit {
  result: any
  submitted = false;

  public products : any;
 searchText:any
  // products: any[] = [];
  //Product: any;


  constructor(private service: CustService) { }

  ngOnInit() {
    this.printTransaction()
     this.products= [
      { prod_Id:1 , prod_Name:'Chair' , prod_Image:'https://res-5.cloudinary.com/dwpujv6in/image/upload/c_pad,dpr_2.0,f_auto,q_auto/v1/media/catalog/product/f/d/fd1_lngchr_bh_frontlow-field-lounge-chair-tait-blush.jpg' , prod_Price:500 , prod_Discount: 0},
     { prod_Id:2 , prod_Name:'Oven' , prod_Image:'https://image.shutterstock.com/image-photo/electric-oven-isolated-on-white-600w-183293252.jpg' , prod_Price: 11500, prod_Discount:18 },
      { prod_Id:3 , prod_Name: 'Shirt', prod_Image:'http://brandstore.vistaprint.in//render/undecorated/product/PVAG-0Q4K507W3K1Y/RS-K82Q06W655QY/jpeg?compression=95&width=700' , prod_Price:1500 , prod_Discount:5 }
   ];
  }

  printTransaction(): void {
    this.service.displayproducts().subscribe(data => {
     this.result = data;
      this.submitted = true;
      console.log(this.result);
    });
 }

  // AddCart(t){
  //   alert("Button is clicked");
  //   console.log(t);
  // }

  
  //searchText;
  




}
