import { Component, OnInit } from '@angular/core';
import {Customer_Orders} from '../cust';
import {CustService} from '../cust.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-total',
  templateUrl: './total.component.html',
  styleUrls: ['./total.component.css']
})
export class TotalComponent implements OnInit {
  private cust: Customer_Orders[];
  res : any
  submitted:any
  prod_Id:number;

  constructor(private router: Router,
    private CustService: CustService) { }

  ngOnInit() {
   this.printTransaction(this.prod_Id)
  }
  
  printTransaction(prod_Id): void {
    this.CustService.showCardlist(prod_Id).subscribe(data => {
      this.res = data;
      console.log(data)
      this.submitted = true;

      
    });
  }
  
}
