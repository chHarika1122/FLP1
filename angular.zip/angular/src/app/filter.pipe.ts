import { Pipe, PipeTransform } from '@angular/core';

import { Product } from './product';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {


  // transform(value: any, args?: any): any {

  //   if(!value)return null;
  //   if(!args)return value;

  //   args = args.toLowerCase();

  //   return value.filter(function(searchText){
  //     return value.filter(searchText).toLowerCase().includes(args);
  //   });

  // }






transform(products : Product[],searchText:string) :Product[]{
  if(products || searchText){
    return products;
  
  }
  return products.filter(Product=>
  Product.prod_Name.toLowerCase().indexOf(searchText.toLowerCase())!==-1);
  
}


}
