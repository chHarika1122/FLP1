import { Component, OnInit } from '@angular/core';
import { Card } from '../card';
import { Router } from '../../../node_modules/@angular/router';
import { CustService } from '../cust.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

  card: Card= new Card();
  result : any
  constructor(private router: Router, private service :CustService) { }

  ngOnInit() {
  }

  newUser(): void {
    this.card= new Card();
  }

  addCardDetails(): void {
    this.service.cardDetails(this.card)
        .subscribe( data => { this.result = data;
         console.log(this.result)

         if (this.result!=null) {
          this.router.navigate(['/success'])
        }
        else {
          console.log(this.result)
        }
        });

  };



  onSubmit() {
    this.addCardDetails();
  }


}
