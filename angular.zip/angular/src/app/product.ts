export class Product {

    prod_Id:any;
    prod_Name:string;
    prod_Price:any;
    prod_Quantity:any;
    prod_Discount:any;
    prod_Category:string;
    prod_Desc:string;
    prod_Image:string;
    merchant_Id:any;
  
  
}
