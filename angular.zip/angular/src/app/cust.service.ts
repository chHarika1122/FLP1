import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { HttpObserve } from '../../node_modules/@angular/common/http/src/client';
import { Observable } from 'rxjs';
import {Customer_Orders} from './cust';
import { Product } from './product';
//import 'rxjs/add/operator/toPromise';
@Injectable({
  providedIn: 'root'
})
export class CustService {
  
  private baseUrl = 'http://localhost:3456';
  //show balance variable
  
    customerId : any;
    productName : string;
    orderId : number;
    quantity : number;
    amount : any;
    pro: Product[]=[];
 

    
  constructor(private http:HttpClient) { }
  
 
  public showOrders(cust) : any  {
    this.customerId = cust.customerId;
    this.productName = cust.productName;
    this.orderId = cust.orderId;
    this.quantity= cust.quantity;
    this.amount = cust.amount;
    return this.http.get(`${this.baseUrl}/${this.customerId}/${this.productName}/${this.orderId}/${this.quantity}/${this.amount}`,{responseType : 'text'});

    // return this.http.get(this.baseUrl)
    // .toPromise()
    // .then(response => response.json() as Customer_Orders[])
   
  }

  public cardDetails(card) :Observable<any>{
    return this.http.post(`${this.baseUrl}`+`/total/card`, card);
  }

  public displayproducts():Observable<any>
  {
    return this.http.get(`http://localhost:3456/showprod`)
  }

    
  // { "prod_Id": 1, "prod_Name": "chair", "prod_Image": "assets/img/chair.jpg" },    
  // { "prod_Id": 2, "prod_Name": "oven", "prod_Image": "assets/img/oven.jpg" },    
  // { "prod_Id": 3, "prod_Name": "shirt", "prod_Image": "assets/img/shirt.jpg" },    
  // { "prod_Id": 4, "prod_Name": "kurta1", "prod_Image": "assets/img/kurta1.jpg" }

  public viewproducts(): Observable<any> {
    return this.http.get(`${this.baseUrl}/login/showProducts/`)
  }

  public displayTotal(customer_id) :Observable<any>{
    return this.http.post(`${this.baseUrl}`+`/cartlist/price/{customer_id}`,{responseType:'text'});
  }

  public showCardlist(prod_Id) :Observable<any>{
    //console.log(prod_Id)
    return this.http.get(`${this.baseUrl}/cartlist/total`)
  }

    

}

 
 

