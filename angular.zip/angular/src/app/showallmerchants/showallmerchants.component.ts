import { Component, OnInit } from '@angular/core';
import { CustService } from '../cust.service';

@Component({
  selector: 'app-showallmerchants',
  templateUrl: './showallmerchants.component.html',
  styleUrls: ['./showallmerchants.component.css']
})
export class ShowallmerchantsComponent implements OnInit {
  result: any
  submitted = false;
  constructor(private service: CustService) { }

  ngOnInit() {
    this.getProducts()
  }
  getProducts(): void {
    this.service.viewproducts().subscribe(data => {
      this.result = data;
      this.submitted = true;
      console.log(this.result);
    });
  }

  

  searchByName(event) {
    this.result = this.result.filter(singleItem =>
      singleItem.prodName.toLowerCase().includes(event.target.value.toLowerCase())
    )
  }
  // searchByMerchantType(event) {
  //   this.result = this.result.filter(singleItem =>
  //     singleItem.merchantType.toLowerCase().includes(event.target.value.toLowerCase())
  //   )
  // }
  // searchByPhone(event) {
  //   this.result = this.result.filter(singleItem =>
  //     singleItem.phoneNo.toLowerCase().includes(event.target.value.toLowerCase())
  //   )
  // }
  // searchByEmail(event) {
  //   this.result = this.result.filter(singleItem =>
  //     singleItem.email.toLowerCase().includes(event.target.value.toLowerCase())
  //   )
  // }
}
