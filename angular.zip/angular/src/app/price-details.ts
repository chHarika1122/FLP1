export class PriceDetails {
    product_Id:any;
    product_Name:string;
    product_Price:any;
    product_Quantity:any;
    Total:any;
}
