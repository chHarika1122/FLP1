import { PriceDetails } from './price-details';

describe('PriceDetails', () => {
  it('should create an instance', () => {
    expect(new PriceDetails()).toBeTruthy();
  });
});
